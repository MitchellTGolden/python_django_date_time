# We must import path here
from django.urls import path 

# We must import our views file from soup/views.py  
from . import views

urlpatterns = [
    path('', views.index),
    path('time_display', views.time_display)
]